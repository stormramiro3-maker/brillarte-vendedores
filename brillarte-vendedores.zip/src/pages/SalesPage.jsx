import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { format } from 'date-fns';
import { es } from 'date-fns/locale';
import { formatPrice } from '@/lib/priceUtils';
import { Loader2, TrendingUp, ShoppingBag, RotateCcw, DollarSign } from 'lucide-react';

const statCard = (icon, label, value, color) => (
  <div className="rounded-2xl p-4 border flex items-center gap-3" style={{ background: '#fff', borderColor: 'rgba(200,0,90,0.1)', boxShadow: '0 2px 12px rgba(200,0,90,0.05)' }}>
    <div className="rounded-xl p-2" style={{ background: `${color}15` }}>
      {React.cloneElement(icon, { className: 'w-5 h-5', style: { color } })}
    </div>
    <div>
      <p className="text-xs" style={{ color: '#993556' }}>{label}</p>
      <p className="text-lg font-bold" style={{ color: '#1A0010' }}>{value}</p>
    </div>
  </div>
);

export default function SalesPage() {
  const [sellerFilter, setSellerFilter] = useState('all');

  const { data: sales = [], isLoading } = useQuery({
    queryKey: ['sales'],
    queryFn: () => base44.entities.Sale.list('-created_date', 500),
    refetchInterval: 5000,
  });

  const sellers = [...new Set(sales.map(s => s.seller).filter(Boolean))];
  const filtered = sellerFilter === 'all' ? sales : sales.filter(s => s.seller === sellerFilter);

  const totalSales = filtered.filter(s => s.type === 'sale');
  const totalReturns = filtered.filter(s => s.type === 'return');
  const totalRevenue = totalSales.reduce((sum, s) => sum + (s.total || 0), 0) - totalReturns.reduce((sum, s) => sum + (s.total || 0), 0);
  const totalUnits = totalSales.reduce((sum, s) => sum + (s.quantity || 0), 0) - totalReturns.reduce((sum, s) => sum + (s.quantity || 0), 0);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-20">
        <Loader2 className="w-7 h-7 animate-spin" style={{ color: '#E8006F' }} />
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between">
        <h1 className="font-display text-2xl font-black" style={{ color: '#1A0010' }}>
          Registro de <span style={{ background: 'linear-gradient(135deg,#C8005A,#E8006F)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent', backgroundClip: 'text' }}>ventas</span>
        </h1>
        {/* Seller filter */}
        <select
          value={sellerFilter}
          onChange={e => setSellerFilter(e.target.value)}
          className="text-sm px-3 py-2 rounded-full outline-none"
          style={{ background: '#fff', border: '1px solid rgba(200,0,90,0.2)', color: '#993556', fontFamily: 'var(--font-body)' }}
        >
          <option value="all">Todos</option>
          {sellers.map(s => <option key={s} value={s}>{s}</option>)}
        </select>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {statCard(<DollarSign />, 'Ingresos netos', formatPrice(totalRevenue), '#C8005A')}
        {statCard(<ShoppingBag />, 'Ventas', totalSales.length, '#2d8a55')}
        {statCard(<TrendingUp />, 'Unidades', totalUnits, '#d4900a')}
        {statCard(<RotateCcw />, 'Devoluciones', totalReturns.length, '#e74c3c')}
      </div>

      {/* Table */}
      <div className="rounded-2xl overflow-hidden border" style={{ background: '#fff', borderColor: 'rgba(200,0,90,0.1)', boxShadow: '0 2px 12px rgba(200,0,90,0.05)' }}>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr style={{ borderBottom: '1px solid rgba(200,0,90,0.08)', background: '#fff9fc' }}>
                {['Hora', 'Producto', 'Tipo', 'Detalle', 'Vendedor', 'Monto'].map(h => (
                  <th key={h} className="text-left px-4 py-3 text-xs font-semibold" style={{ color: '#993556' }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filtered.length === 0 ? (
                <tr>
                  <td colSpan={6} className="text-center py-12 text-sm" style={{ color: '#993556', opacity: 0.5 }}>
                    No hay ventas registradas aún
                  </td>
                </tr>
              ) : (
                filtered.map(sale => (
                  <tr key={sale.id} style={{ borderBottom: '1px solid rgba(200,0,90,0.06)' }}>
                    <td className="px-4 py-3 whitespace-nowrap text-xs" style={{ color: '#993556' }}>
                      {sale.created_date ? format(new Date(sale.created_date), 'HH:mm', { locale: es }) : '-'}
                    </td>
                    <td className="px-4 py-3 font-medium" style={{ color: '#1A0010' }}>{sale.product_name}</td>
                    <td className="px-4 py-3">
                      <span
                        className="text-xs font-semibold px-2.5 py-1 rounded-full"
                        style={
                          sale.type === 'sale'
                            ? { background: 'rgba(200,0,90,0.08)', color: '#C8005A', border: '1px solid rgba(200,0,90,0.2)' }
                            : { background: 'rgba(231,76,60,0.08)', color: '#e74c3c', border: '1px solid rgba(231,76,60,0.2)' }
                        }
                      >
                        {sale.type === 'sale' ? 'Venta' : 'Devolución'}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-xs" style={{ color: '#D4537E' }}>
                      {sale.sub_category}{sale.size ? ` · ${sale.size}` : ''}
                    </td>
                    <td className="px-4 py-3 text-sm" style={{ color: '#2A0018' }}>{sale.seller}</td>
                    <td className="px-4 py-3 text-right font-semibold" style={{ color: sale.type === 'return' ? '#e74c3c' : '#C8005A' }}>
                      {sale.type === 'return' ? '-' : ''}{formatPrice(sale.total || 0)}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}