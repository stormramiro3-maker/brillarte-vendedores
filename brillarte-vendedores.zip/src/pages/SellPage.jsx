import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import ProductFilters from '@/components/sell/ProductFilters';
import ProductCard from '@/components/sell/ProductCard';
import { Loader2, PackageSearch } from 'lucide-react';

export default function SellPage() {
  const queryClient = useQueryClient();
  const [filters, setFilters] = useState({
    main: '', sub: '', size: '', tag: '', search: '', stockOnly: false
  });

  const { data: products = [], isLoading: loadingProducts } = useQuery({
    queryKey: ['products'],
    queryFn: () => base44.entities.Product.list('-created_date', 500),
  });

  const { data: priceRules = [] } = useQuery({
    queryKey: ['priceRules'],
    queryFn: () => base44.entities.PriceRule.list('-created_date', 100),
  });

  // Real-time subscription
  useEffect(() => {
    const unsubscribe = base44.entities.Product.subscribe((event) => {
      if (event.type === 'update') {
        queryClient.setQueryData(['products'], old => old?.map(p => p.id === event.id ? { ...p, ...event.data } : p));
      } else if (event.type === 'create') {
        queryClient.invalidateQueries({ queryKey: ['products'] });
      } else if (event.type === 'delete') {
        queryClient.setQueryData(['products'], old => old?.filter(p => p.id !== event.id));
      }
    });
    return unsubscribe;
  }, [queryClient]);

  const filtered = products.filter(p => {
    if (!p.active) return false;
    if (filters.main && p.main_category !== filters.main) return false;
    if (filters.sub && p.sub_category !== filters.sub) return false;
    if (filters.size && p.size !== filters.size) return false;
    if (filters.tag && p.tag1 !== filters.tag && p.tag2 !== filters.tag && p.tag3 !== filters.tag) return false;
    if (filters.search) {
      const q = filters.search.toLowerCase();
      if (!p.name?.toLowerCase().includes(q)) return false;
    }
    if (filters.stockOnly && (p.stock || 0) <= 0) return false;
    return true;
  });

  if (loadingProducts) {
    return (
      <div className="flex items-center justify-center py-20">
        <div className="flex flex-col items-center gap-3">
          <Loader2 className="w-7 h-7 animate-spin" style={{ color: '#E8006F' }} />
          <p className="text-sm" style={{ color: '#993556' }}>Cargando productos...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <ProductFilters filters={filters} setFilters={setFilters} products={products.filter(p => p.active)} />

      <p className="text-xs" style={{ color: '#993556', opacity: 0.6 }}>
        {filtered.length} producto{filtered.length !== 1 ? 's' : ''}
      </p>

      {filtered.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-16" style={{ color: '#993556' }}>
          <PackageSearch className="w-12 h-12 mb-3" style={{ opacity: 0.4 }} />
          <p className="font-medium">No se encontraron productos</p>
          <p className="text-sm" style={{ opacity: 0.6 }}>Probá ajustando los filtros</p>
        </div>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-3">
          {filtered.map(product => (
            <ProductCard key={product.id} product={product} priceRules={priceRules} />
          ))}
        </div>
      )}
    </div>
  );
}