import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { Upload, Download, Trash2, Loader2, CheckCircle, AlertTriangle, Database, FileSpreadsheet } from 'lucide-react';
import { toast } from 'sonner';
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader,
  AlertDialogTitle, AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

const SyncCard = ({ icon, iconColor, iconBg, title, description, children }) => (
  <div className="rounded-2xl p-5 border" style={{ background: '#fff', borderColor: 'rgba(200,0,90,0.1)', boxShadow: '0 2px 12px rgba(200,0,90,0.05)' }}>
    <div className="flex items-start gap-3 mb-4">
      <div className="rounded-xl p-2.5 shrink-0" style={{ background: iconBg }}>
        {React.cloneElement(icon, { className: 'w-5 h-5', style: { color: iconColor } })}
      </div>
      <div>
        <p className="font-semibold" style={{ color: '#1A0010' }}>{title}</p>
        <p className="text-xs mt-0.5" style={{ color: '#993556', opacity: 0.75 }}>{description}</p>
      </div>
    </div>
    {children}
  </div>
);

export default function SyncPage() {
  const queryClient = useQueryClient();
  const [importing, setImporting] = useState(false);
  const [importResult, setImportResult] = useState(null);
  const [exporting, setExporting] = useState(false);

  const { data: products = [] } = useQuery({
    queryKey: ['products'],
    queryFn: () => base44.entities.Product.list('-created_date', 500),
  });

  const { data: priceRules = [] } = useQuery({
    queryKey: ['priceRules'],
    queryFn: () => base44.entities.PriceRule.list('-created_date', 100),
  });

  const handleImport = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setImporting(true);
    setImportResult(null);

    const { file_url } = await base44.integrations.Core.UploadFile({ file });

    const productData = await base44.integrations.Core.ExtractDataFromUploadedFile({
      file_url,
      json_schema: {
        type: "object",
        properties: {
          products: { type: "array", items: { type: "object", properties: { Activo: { type: "boolean" }, Main: { type: "string" }, Sub: { type: "string" }, Size: { type: "string" }, Producto: { type: "string" }, Imagen: { type: "string" }, Stock: { type: "number" }, "Tag 1": { type: "string" }, "Tag 2": { type: "string" }, "Tag 3": { type: "string" }, "Nombre para Cloudinary": { type: "string" } } } },
          precios: { type: "array", items: { type: "object", properties: { Sub: { type: "string" }, Size: { type: "string" }, Precio: { type: "string" } } } }
        }
      }
    });

    if (productData.status === 'error') {
      toast.error('Error al extraer datos: ' + productData.details);
      setImporting(false);
      return;
    }

    const extracted = productData.output;
    const newProducts = extracted.products || [];
    const newPrices = extracted.precios || [];

    const oldProducts = await base44.entities.Product.list('-created_date', 500);
    for (const p of oldProducts) await base44.entities.Product.delete(p.id);
    const oldPrices = await base44.entities.PriceRule.list('-created_date', 100);
    for (const p of oldPrices) await base44.entities.PriceRule.delete(p.id);

    if (newProducts.length > 0) {
      const mapped = newProducts.map(row => ({
        active: row.Activo !== false,
        main_category: row.Main || '', sub_category: row.Sub || '', size: row.Size || '',
        name: row.Producto || '', image_url: row.Imagen || '', stock: row.Stock || 0,
        tag1: row['Tag 1'] || '', tag2: row['Tag 2'] || '', tag3: row['Tag 3'] || '',
        cloudinary_name: row['Nombre para Cloudinary'] || '',
      }));
      for (let i = 0; i < mapped.length; i += 50) {
        await base44.entities.Product.bulkCreate(mapped.slice(i, i + 50));
      }
    }

    if (newPrices.length > 0) {
      const mappedPrices = newPrices.map(row => ({ sub_category: row.Sub || '', size: row.Size || '', price: parseFloat(row.Precio) || 0 }));
      await base44.entities.PriceRule.bulkCreate(mappedPrices);
    }

    setImportResult({ products: newProducts.length, prices: newPrices.length });
    queryClient.invalidateQueries({ queryKey: ['products'] });
    queryClient.invalidateQueries({ queryKey: ['priceRules'] });
    toast.success(`Importados ${newProducts.length} productos y ${newPrices.length} precios`);
    setImporting(false);
    e.target.value = '';
  };

  const handleExport = async () => {
    setExporting(true);
    const headers = ['Activo', 'Main', 'Sub', 'Size', 'Producto', 'Imagen', 'Stock', 'Tag 1', 'Tag 2', 'Tag 3', 'Nombre para Cloudinary'];
    const rows = products.map(p => [p.active ? 'TRUE' : 'FALSE', p.main_category || '', p.sub_category || '', p.size || '', p.name || '', p.image_url || '', p.stock || 0, p.tag1 || '', p.tag2 || '', p.tag3 || '', p.cloudinary_name || '']);
    let csv = '\uFEFF' + headers.join(',') + '\n';
    rows.forEach(row => { csv += row.map(cell => { const s = String(cell); return (s.includes(',') || s.includes('"') || s.includes('\n')) ? '"' + s.replace(/"/g, '""') + '"' : s; }).join(',') + '\n'; });
    csv += '\n\n--- PRECIOS ---\nSub,Size,Precio\n';
    priceRules.forEach(pr => { csv += `${pr.sub_category},${pr.size},${pr.price}\n`; });
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `BrillArteBD_export_${new Date().toISOString().split('T')[0]}.csv`;
    link.click();
    URL.revokeObjectURL(url);
    setExporting(false);
    toast.success('Archivo exportado correctamente');
  };

  const handleClearSales = async () => {
    const sales = await base44.entities.Sale.list('-created_date', 500);
    for (const s of sales) await base44.entities.Sale.delete(s.id);
    queryClient.invalidateQueries({ queryKey: ['sales'] });
    toast.success('Historial de ventas limpiado');
  };

  const withStock = products.filter(p => (p.stock || 0) > 0).length;
  const noStock = products.filter(p => (p.stock || 0) <= 0).length;

  return (
    <div className="space-y-4 max-w-xl mx-auto">
      <h1 className="font-display text-2xl font-black" style={{ color: '#1A0010' }}>
        Sincro<span style={{ background: 'linear-gradient(135deg,#C8005A,#E8006F)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent', backgroundClip: 'text' }}>nizar</span>
      </h1>

      {/* Import */}
      <SyncCard icon={<Upload />} iconColor="#C8005A" iconBg="rgba(200,0,90,0.08)" title="Importar desde Excel" description="Cargá el .xlsx actualizado. Reemplaza todos los productos y precios.">
        <label className="block">
          <input
            type="file"
            accept=".xlsx,.xls,.csv"
            onChange={handleImport}
            disabled={importing}
            className="w-full text-sm cursor-pointer file:mr-3 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-xs file:font-medium file:cursor-pointer"
            style={{ color: '#993556' }}
          />
        </label>
        {importing && (
          <div className="flex items-center gap-2 text-sm mt-3" style={{ color: '#993556' }}>
            <Loader2 className="w-4 h-4 animate-spin" style={{ color: '#E8006F' }} />
            Importando... esto puede tardar un momento
          </div>
        )}
        {importResult && (
          <div className="flex items-center gap-2 text-sm mt-3" style={{ color: '#2d8a55' }}>
            <CheckCircle className="w-4 h-4" />
            {importResult.products} productos y {importResult.prices} precios importados
          </div>
        )}
      </SyncCard>

      {/* Export */}
      <SyncCard icon={<Download />} iconColor="#d4900a" iconBg="rgba(212,144,10,0.1)" title="Exportar datos actuales" description="Descargá el estado actual del stock para cotejar con la BD en la nube.">
        <div className="flex items-center gap-3">
          <button
            onClick={handleExport}
            disabled={exporting}
            className="flex items-center gap-2 px-4 py-2 rounded-full text-sm font-medium transition-all"
            style={{ background: 'rgba(200,0,90,0.08)', color: '#C8005A', border: '1px solid rgba(200,0,90,0.2)' }}
          >
            {exporting ? <Loader2 className="w-4 h-4 animate-spin" /> : <FileSpreadsheet className="w-4 h-4" />}
            Exportar CSV
          </button>
          <span className="text-xs px-2.5 py-1 rounded-full" style={{ background: 'rgba(200,0,90,0.06)', color: '#993556', border: '1px solid rgba(200,0,90,0.15)' }}>
            {products.length} productos
          </span>
        </div>
      </SyncCard>

      {/* DB Status */}
      <SyncCard icon={<Database />} iconColor="#993556" iconBg="rgba(200,0,90,0.06)" title="Estado de la base de datos" description="Información actual del sistema">
        <div className="grid grid-cols-2 gap-2">
          {[
            { label: 'Total productos', value: products.length },
            { label: 'Con stock', value: withStock, color: '#2d8a55' },
            { label: 'Sin stock', value: noStock, color: '#e74c3c' },
            { label: 'Reglas de precio', value: priceRules.length },
          ].map(({ label, value, color }) => (
            <div key={label} className="rounded-xl p-3" style={{ background: '#fff9fc', border: '1px solid rgba(200,0,90,0.08)' }}>
              <p className="text-xs mb-1" style={{ color: '#993556', opacity: 0.7 }}>{label}</p>
              <p className="text-xl font-bold" style={{ color: color || '#1A0010' }}>{value}</p>
            </div>
          ))}
        </div>
      </SyncCard>

      {/* Danger zone */}
      <SyncCard icon={<AlertTriangle />} iconColor="#e74c3c" iconBg="rgba(231,76,60,0.08)" title="Zona peligrosa" description="Acciones irreversibles">
        <AlertDialog>
          <AlertDialogTrigger asChild>
            <button
              className="flex items-center gap-2 px-4 py-2 rounded-full text-sm font-medium transition-all"
              style={{ background: 'rgba(231,76,60,0.08)', color: '#e74c3c', border: '1px solid rgba(231,76,60,0.2)' }}
            >
              <Trash2 className="w-4 h-4" />
              Limpiar historial de ventas
            </button>
          </AlertDialogTrigger>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>¿Estás seguro?</AlertDialogTitle>
              <AlertDialogDescription>
                Esto eliminará todo el historial de ventas de esta feria. Esta acción no se puede deshacer.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Cancelar</AlertDialogCancel>
              <AlertDialogAction onClick={handleClearSales}>Sí, limpiar todo</AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </SyncCard>
    </div>
  );
}