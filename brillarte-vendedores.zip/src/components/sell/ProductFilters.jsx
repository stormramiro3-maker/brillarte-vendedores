import React from 'react';
import { Search, X, Filter, SlidersHorizontal } from 'lucide-react';

export default function ProductFilters({ filters, setFilters, products }) {
  const mainCategories = [...new Set(products.map(p => p.main_category).filter(Boolean))];
  const subCategories = [...new Set(
    products.filter(p => !filters.main || p.main_category === filters.main).map(p => p.sub_category).filter(Boolean)
  )];
  const sizes = [...new Set(
    products
      .filter(p => !filters.main || p.main_category === filters.main)
      .filter(p => !filters.sub || p.sub_category === filters.sub)
      .map(p => p.size).filter(Boolean)
  )].sort();

  const activeCount = [filters.main, filters.sub, filters.size, filters.tag, filters.search, filters.stockOnly].filter(Boolean).length;
  const clearAll = () => setFilters({ main: '', sub: '', size: '', tag: '', search: '', stockOnly: false });

  const chipStyle = (active) => ({
    padding: '0.32rem 0.8rem',
    borderRadius: 50,
    fontSize: '0.78rem',
    cursor: 'pointer',
    border: active ? '1px solid #C8005A' : '1px solid rgba(200,0,90,0.2)',
    background: active ? 'rgba(200,0,90,0.08)' : '#fff',
    color: active ? '#C8005A' : '#993556',
    fontWeight: active ? 500 : 400,
    whiteSpace: 'nowrap',
    transition: 'all 0.15s',
    fontFamily: 'var(--font-body)',
  });

  return (
    <div className="space-y-3">
      {/* Search row */}
      <div className="flex items-center gap-2">
        <div
          className="flex-1 flex items-center gap-2 px-3 py-2 rounded-full transition-all"
          style={{ background: '#fff', border: '1px solid rgba(200,0,90,0.2)' }}
        >
          <Search className="w-4 h-4 shrink-0" style={{ color: '#C8005A' }} />
          <input
            placeholder="Buscar producto..."
            value={filters.search}
            onChange={e => setFilters(f => ({ ...f, search: e.target.value }))}
            className="flex-1 outline-none bg-transparent text-sm min-w-0"
            style={{ color: '#2A0018', fontFamily: 'var(--font-body)' }}
          />
          {filters.search && (
            <button onClick={() => setFilters(f => ({ ...f, search: '' }))} style={{ color: '#C8005A' }}>
              <X className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
        {activeCount > 0 && (
          <button
            onClick={clearAll}
            className="flex items-center gap-1 px-3 py-2 rounded-full text-xs font-medium transition-all"
            style={{ color: '#993556', border: '1px solid rgba(200,0,90,0.2)', background: '#fff' }}
          >
            <X className="w-3 h-3" />
            Quitar ({activeCount})
          </button>
        )}
      </div>

      {/* Filter chips — horizontal scroll on mobile */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 -mx-1 px-1" style={{ scrollbarWidth: 'none' }}>
        <SlidersHorizontal className="w-3.5 h-3.5 shrink-0" style={{ color: '#993556', opacity: 0.6 }} />

        {/* Stock toggle */}
        <button style={chipStyle(filters.stockOnly)} onClick={() => setFilters(f => ({ ...f, stockOnly: !f.stockOnly }))}>
          Con stock
        </button>

        {/* Main categories */}
        {mainCategories.map(cat => (
          <button
            key={cat}
            style={chipStyle(filters.main === cat)}
            onClick={() => setFilters(f => ({ ...f, main: f.main === cat ? '' : cat, sub: '', size: '' }))}
          >
            {cat}
          </button>
        ))}

        {/* Subcategories (when main selected) */}
        {filters.main && subCategories.map(sub => (
          <button
            key={sub}
            style={chipStyle(filters.sub === sub)}
            onClick={() => setFilters(f => ({ ...f, sub: f.sub === sub ? '' : sub, size: '' }))}
          >
            {sub}
          </button>
        ))}

        {/* Sizes */}
        {sizes.length > 0 && sizes.map(size => (
          <button
            key={size}
            style={chipStyle(filters.size === size)}
            onClick={() => setFilters(f => ({ ...f, size: f.size === size ? '' : size }))}
          >
            {size}
          </button>
        ))}
      </div>
    </div>
  );
}