import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useSeller } from '@/lib/sellerContext';
import { findPrice, formatPrice } from '@/lib/priceUtils';
import { Minus, Plus, ShoppingBag } from 'lucide-react';
import { toast } from 'sonner';
import { useQueryClient } from '@tanstack/react-query';

export default function ProductCard({ product, priceRules }) {
  const { seller } = useSeller();
  const [busy, setBusy] = useState(false);
  const queryClient = useQueryClient();
  const price = findPrice(priceRules, product.sub_category, product.size);
  const outOfStock = (product.stock || 0) <= 0;
  const lowStock = !outOfStock && product.stock <= 2;

  const handleSell = async () => {
    if (outOfStock || busy) return;
    setBusy(true);
    queryClient.setQueryData(['products'], old => old?.map(p => p.id === product.id ? { ...p, stock: (p.stock || 0) - 1 } : p));
    await base44.entities.Product.update(product.id, { stock: (product.stock || 0) - 1 });
    await base44.entities.Sale.create({
      product_id: product.id, product_name: product.name,
      main_category: product.main_category, sub_category: product.sub_category,
      size: product.size, quantity: 1, unit_price: price, total: price,
      seller, type: 'sale',
    });
    toast.success(`Vendido: ${product.name}`);
    setBusy(false);
  };

  const handleReturn = async () => {
    if (busy) return;
    setBusy(true);
    queryClient.setQueryData(['products'], old => old?.map(p => p.id === product.id ? { ...p, stock: (p.stock || 0) + 1 } : p));
    await base44.entities.Product.update(product.id, { stock: (product.stock || 0) + 1 });
    await base44.entities.Sale.create({
      product_id: product.id, product_name: product.name,
      main_category: product.main_category, sub_category: product.sub_category,
      size: product.size, quantity: 1, unit_price: price, total: price,
      seller, type: 'return',
    });
    toast.info(`Devuelto: ${product.name}`);
    setBusy(false);
  };

  return (
    <div
      className="rounded-2xl overflow-hidden transition-all"
      style={{
        background: '#fff',
        border: '1px solid rgba(200,0,90,0.1)',
        opacity: outOfStock ? 0.55 : 1,
        boxShadow: outOfStock ? 'none' : '0 2px 12px rgba(200,0,90,0.06)',
      }}
      onMouseEnter={e => { if (!outOfStock) { e.currentTarget.style.transform = 'translateY(-3px)'; e.currentTarget.style.borderColor = 'rgba(200,0,90,0.25)'; e.currentTarget.style.boxShadow = '0 8px 24px rgba(200,0,90,0.1)'; } }}
      onMouseLeave={e => { e.currentTarget.style.transform = 'none'; e.currentTarget.style.borderColor = 'rgba(200,0,90,0.1)'; e.currentTarget.style.boxShadow = outOfStock ? 'none' : '0 2px 12px rgba(200,0,90,0.06)'; }}
    >
      {/* Image */}
      <div className="relative overflow-hidden" style={{ height: 150, background: 'linear-gradient(135deg,#fce8f1,#f4c0d1)' }}>
        {product.image_url ? (
          <img src={product.image_url} alt={product.name} className="w-full h-full object-cover" loading="lazy" />
        ) : (
          <div className="w-full h-full flex items-center justify-center">
            <ShoppingBag className="w-8 h-8" style={{ color: '#D4537E' }} />
          </div>
        )}

        {/* Stock badge */}
        <div className="absolute top-2 right-2">
          <span
            className="text-xs font-bold px-2 py-0.5 rounded-full"
            style={
              outOfStock
                ? { background: 'rgba(200,0,90,0.85)', color: '#fff' }
                : lowStock
                ? { background: '#fff', color: '#E8006F', border: '1px solid rgba(200,0,90,0.35)' }
                : { background: 'rgba(255,255,255,0.9)', color: '#2d8a55', border: '1px solid rgba(45,138,85,0.3)' }
            }
          >
            {outOfStock ? 'Sin stock' : lowStock ? `¡Últ. ${product.stock}!` : `${product.stock} uds`}
          </span>
        </div>
      </div>

      {/* Info */}
      <div className="p-3">
        <h3 className="font-medium text-sm leading-snug truncate mb-0.5" style={{ color: '#1A0010' }}>{product.name}</h3>
        <p className="text-xs mb-1.5 truncate" style={{ color: '#D4537E' }}>
          {product.sub_category}{product.size ? ` · ${product.size}` : ''}
        </p>

        {price > 0 && (
          <p className="text-base font-bold mb-2.5" style={{ color: '#C8005A' }}>{formatPrice(price)}</p>
        )}

        {/* Actions */}
        <div className="flex gap-1.5">
          <button
            className="flex items-center justify-center rounded-xl transition-all"
            style={{
              width: 38, height: 38, flexShrink: 0,
              background: 'rgba(200,0,90,0.07)',
              border: '1px solid rgba(200,0,90,0.18)',
              color: '#C8005A',
            }}
            onClick={handleReturn}
            disabled={busy}
            title="Devolver / +1 stock"
            onMouseEnter={e => { e.currentTarget.style.background = 'rgba(200,0,90,0.15)'; }}
            onMouseLeave={e => { e.currentTarget.style.background = 'rgba(200,0,90,0.07)'; }}
          >
            <Plus className="w-4 h-4" />
          </button>
          <button
            className="flex-1 flex items-center justify-center gap-1.5 rounded-xl text-sm font-medium text-white transition-all"
            style={
              outOfStock || busy
                ? { background: 'rgba(200,0,90,0.1)', color: '#993556', cursor: 'not-allowed' }
                : { background: 'linear-gradient(135deg,#E8006F,#C8005A)', boxShadow: '0 4px 14px rgba(200,0,90,0.25)' }
            }
            onClick={handleSell}
            disabled={outOfStock || busy}
          >
            <Minus className="w-3.5 h-3.5" />
            Vender
          </button>
        </div>
      </div>
    </div>
  );
}