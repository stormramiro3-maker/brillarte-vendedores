import React from 'react';
import { Outlet, Link, useLocation } from 'react-router-dom';
import { useSeller } from '@/lib/sellerContext';
import { ShoppingBag, BarChart3, RefreshCw, LogOut } from 'lucide-react';

const navItems = [
  { path: '/', label: 'Vender', icon: ShoppingBag },
  { path: '/ventas', label: 'Ventas', icon: BarChart3 },
  { path: '/sync', label: 'Sync', icon: RefreshCw },
];

export default function AppLayout() {
  const { seller, clearSeller } = useSeller();
  const location = useLocation();

  return (
    <div className="min-h-screen flex flex-col" style={{ background: '#fff5f9', color: '#2A0018' }}>

      {/* TOP NAV — visible en desktop, oculto en mobile */}
      <header
        className="hidden md:flex sticky top-0 z-50 items-center justify-between px-6 h-14 border-b"
        style={{
          background: 'rgba(255,255,255,0.92)',
          backdropFilter: 'blur(20px)',
          borderColor: 'rgba(200,0,90,0.12)',
        }}
      >
        {/* Logo */}
        <span className="font-display text-xl font-black" style={{ color: '#2A0018' }}>
          Brill<span style={{ color: '#E8006F' }}>Arte</span>
        </span>

        {/* Nav links */}
        <nav className="flex items-center gap-1">
          {navItems.map(item => {
            const active = location.pathname === item.path;
            return (
              <Link key={item.path} to={item.path}>
                <button
                  className="flex items-center gap-2 px-4 py-2 rounded-full text-sm font-medium transition-all"
                  style={
                    active
                      ? { background: 'linear-gradient(135deg,#E8006F,#C8005A)', color: '#fff', boxShadow: '0 4px 14px rgba(200,0,90,0.25)' }
                      : { color: '#993556', border: '1.5px solid rgba(200,0,90,0.2)' }
                  }
                >
                  <item.icon className="w-4 h-4" />
                  {item.label}
                </button>
              </Link>
            );
          })}
        </nav>

        {/* Seller + logout */}
        <div className="flex items-center gap-3">
          <span className="text-xs font-medium px-3 py-1 rounded-full" style={{ background: 'rgba(200,0,90,0.08)', color: '#C8005A', border: '1px solid rgba(200,0,90,0.2)' }}>
            {seller}
          </span>
          <button
            onClick={clearSeller}
            className="flex items-center gap-1.5 text-xs transition-all px-3 py-1.5 rounded-full"
            style={{ color: '#993556', border: '1px solid rgba(200,0,90,0.2)' }}
            onMouseEnter={e => { e.currentTarget.style.background = 'rgba(200,0,90,0.06)'; e.currentTarget.style.borderColor = 'rgba(200,0,90,0.4)'; }}
            onMouseLeave={e => { e.currentTarget.style.background = 'transparent'; e.currentTarget.style.borderColor = 'rgba(200,0,90,0.2)'; }}
          >
            <LogOut className="w-3.5 h-3.5" />
            Cambiar
          </button>
        </div>
      </header>

      {/* MOBILE TOP BAR */}
      <header
        className="flex md:hidden sticky top-0 z-50 items-center justify-between px-4 h-12 border-b"
        style={{
          background: 'rgba(255,255,255,0.95)',
          backdropFilter: 'blur(20px)',
          borderColor: 'rgba(200,0,90,0.12)',
        }}
      >
        <span className="font-display text-lg font-black" style={{ color: '#2A0018' }}>
          Brill<span style={{ color: '#E8006F' }}>Arte</span>
        </span>
        <span className="text-xs font-medium px-2.5 py-1 rounded-full" style={{ background: 'rgba(200,0,90,0.08)', color: '#C8005A', border: '1px solid rgba(200,0,90,0.2)' }}>
          {seller}
        </span>
      </header>

      {/* MAIN CONTENT — con padding-bottom para no quedar tapado por bottom nav en mobile */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-3 sm:px-4 md:px-6 py-4 pb-24 md:pb-6">
        <Outlet />
      </main>

      {/* BOTTOM NAV — solo mobile */}
      <nav
        className="fixed bottom-0 left-0 right-0 z-50 flex md:hidden border-t"
        style={{
          background: 'rgba(255,255,255,0.97)',
          backdropFilter: 'blur(20px)',
          borderColor: 'rgba(200,0,90,0.12)',
        }}
      >
        {navItems.map(item => {
          const active = location.pathname === item.path;
          return (
            <Link key={item.path} to={item.path} className="flex-1">
              <button
                className="w-full flex flex-col items-center justify-center gap-0.5 py-3 transition-all"
                style={{ color: active ? '#E8006F' : '#993556' }}
              >
                <item.icon className="w-5 h-5" strokeWidth={active ? 2.5 : 1.75} />
                <span className="text-[10px] font-medium">{item.label}</span>
                {active && (
                  <span className="absolute bottom-0 w-6 h-0.5 rounded-full" style={{ background: '#E8006F' }} />
                )}
              </button>
            </Link>
          );
        })}
        <button
          onClick={clearSeller}
          className="flex-1 flex flex-col items-center justify-center gap-0.5 py-3 transition-all"
          style={{ color: '#993556' }}
        >
          <LogOut className="w-5 h-5" strokeWidth={1.75} />
          <span className="text-[10px] font-medium">Salir</span>
        </button>
      </nav>
    </div>
  );
}