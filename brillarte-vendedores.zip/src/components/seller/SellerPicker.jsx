import React, { useState } from 'react';
import { useSeller } from '@/lib/sellerContext';
import { UserPlus } from 'lucide-react';

const PRESET_SELLERS = ['Vendedor 1', 'Vendedor 2', 'Vendedor 3', 'Vendedor 4', 'Vendedor 5'];

export default function SellerPicker() {
  const { selectSeller } = useSeller();
  const [customName, setCustomName] = useState('');

  return (
    <div className="min-h-screen flex items-center justify-center p-4" style={{ background: '#fff5f9', color: '#2A0018' }}>

      {/* blobs decorativos */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden">
        <div className="absolute rounded-full" style={{ width: 500, height: 500, background: '#f4c0d1', opacity: 0.45, filter: 'blur(100px)', top: -100, left: -150 }} />
        <div className="absolute rounded-full" style={{ width: 380, height: 380, background: '#ed93b1', opacity: 0.3, filter: 'blur(100px)', bottom: -80, right: -100 }} />
      </div>

      <div className="w-full max-w-sm relative z-10">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="inline-block px-4 py-1.5 rounded-full text-xs font-medium mb-4 tracking-widest uppercase" style={{ background: 'rgba(200,0,90,0.08)', border: '1px solid rgba(200,0,90,0.2)', color: '#C8005A' }}>
            ✦ Panel de Vendedores ✦
          </div>
          <h1 className="font-display text-4xl font-black mb-2" style={{ color: '#1A0010' }}>
            Brill<span style={{ background: 'linear-gradient(135deg,#C8005A,#E8006F)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent', backgroundClip: 'text' }}>Arte</span>
          </h1>
          <p className="text-sm" style={{ color: '#993556' }}>
            Seleccioná tu puesto para comenzar
          </p>
        </div>

        {/* Card */}
        <div
          className="rounded-2xl p-6 border"
          style={{
            background: '#fff',
            borderColor: 'rgba(200,0,90,0.12)',
            boxShadow: '0 12px 40px rgba(200,0,90,0.1)',
          }}
        >
          <div className="grid grid-cols-2 gap-2 mb-5">
            {PRESET_SELLERS.map(name => (
              <button
                key={name}
                onClick={() => selectSeller(name)}
                className="py-3 px-4 rounded-xl text-sm font-medium transition-all border"
                style={{ background: '#fff', borderColor: 'rgba(200,0,90,0.18)', color: '#993556' }}
                onMouseEnter={e => { e.currentTarget.style.background = 'rgba(200,0,90,0.06)'; e.currentTarget.style.borderColor = 'rgba(200,0,90,0.4)'; e.currentTarget.style.color = '#C8005A'; }}
                onMouseLeave={e => { e.currentTarget.style.background = '#fff'; e.currentTarget.style.borderColor = 'rgba(200,0,90,0.18)'; e.currentTarget.style.color = '#993556'; }}
              >
                {name}
              </button>
            ))}
          </div>

          {/* Divider */}
          <div className="flex items-center gap-3 mb-5">
            <div className="flex-1 border-t" style={{ borderColor: 'rgba(200,0,90,0.12)' }} />
            <span className="text-xs" style={{ color: '#993556', opacity: 0.6 }}>o ingresá tu nombre</span>
            <div className="flex-1 border-t" style={{ borderColor: 'rgba(200,0,90,0.12)' }} />
          </div>

          <div className="flex gap-2">
            <input
              placeholder="Tu nombre..."
              value={customName}
              onChange={e => setCustomName(e.target.value)}
              onKeyDown={e => e.key === 'Enter' && customName.trim() && selectSeller(customName.trim())}
              className="flex-1 px-4 py-2.5 rounded-xl text-sm outline-none transition-all border"
              style={{
                background: '#fff',
                borderColor: 'rgba(200,0,90,0.2)',
                color: '#2A0018',
                fontFamily: 'var(--font-body)',
              }}
              onFocus={e => e.currentTarget.style.borderColor = 'rgba(200,0,90,0.5)'}
              onBlur={e => e.currentTarget.style.borderColor = 'rgba(200,0,90,0.2)'}
            />
            <button
              disabled={!customName.trim()}
              onClick={() => customName.trim() && selectSeller(customName.trim())}
              className="btn-magenta px-4 py-2.5 rounded-xl text-white text-sm font-medium flex items-center gap-2 disabled:opacity-40 disabled:cursor-not-allowed disabled:shadow-none disabled:transform-none"
            >
              <UserPlus className="w-4 h-4" />
              Entrar
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}