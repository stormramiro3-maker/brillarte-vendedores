import { Toaster } from "@/components/ui/toaster"
import { QueryClientProvider } from '@tanstack/react-query'
import { queryClientInstance } from '@/lib/query-client'
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import PageNotFound from './lib/PageNotFound';
import { AuthProvider, useAuth } from '@/lib/AuthContext';
import UserNotRegisteredError from '@/components/UserNotRegisteredError';
import { SellerProvider } from '@/lib/sellerContext';
import AppLayout from '@/components/layout/AppLayout';
import SellerPicker from '@/components/seller/SellerPicker';
import SellPage from '@/pages/SellPage';
import SalesPage from '@/pages/SalesPage';
import SyncPage from '@/pages/SyncPage';
import { useSeller } from '@/lib/sellerContext';

const SellerGate = () => {
  const { seller } = useSeller();
  if (!seller) return <SellerPicker />;
  return (
    <Routes>
      <Route element={<AppLayout />}>
        <Route path="/" element={<SellPage />} />
        <Route path="/ventas" element={<SalesPage />} />
        <Route path="/sync" element={<SyncPage />} />
      </Route>
      <Route path="*" element={<PageNotFound />} />
    </Routes>
  );
};

const AuthenticatedApp = () => {
  const { isLoadingAuth, isLoadingPublicSettings, authError, navigateToLogin } = useAuth();

  // Show loading spinner while checking app public settings or auth
  if (isLoadingPublicSettings || isLoadingAuth) {
    return (
      <div className="fixed inset-0 flex items-center justify-center">
        <div className="w-8 h-8 border-4 border-slate-200 border-t-slate-800 rounded-full animate-spin"></div>
      </div>
    );
  }

  // Handle authentication errors
  if (authError) {
    if (authError.type === 'user_not_registered') {
      return <UserNotRegisteredError />;
    } else if (authError.type === 'auth_required') {
      // Redirect to login automatically
      navigateToLogin();
      return null;
    }
  }

  // Render the main app
  return (
    <SellerProvider>
      <SellerGate />
    </SellerProvider>
  );
};


function App() {

  return (
    <AuthProvider>
      <QueryClientProvider client={queryClientInstance}>
        <Router>
          <AuthenticatedApp />
        </Router>
        <Toaster />
      </QueryClientProvider>
    </AuthProvider>
  )
}

export default App